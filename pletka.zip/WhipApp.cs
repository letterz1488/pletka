using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Pletka
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.ThreadException += delegate(object sender, System.Threading.ThreadExceptionEventArgs e)
            {
                MessageBox.Show(e.Exception.ToString(), "\u041F\u043B\u0451\u0442\u043A\u0430", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };
            Application.Run(new WhipForm());
        }
    }

    sealed class WhipForm : Form
    {
        const int WS_EX_LAYERED = 0x00080000;
        const int ULW_ALPHA = 0x02;
        const byte AC_SRC_OVER = 0x00;
        const byte AC_SRC_ALPHA = 0x01;
        const uint SND_ASYNC = 0x0001;
        const uint SND_NODEFAULT = 0x0002;
        const uint SND_MEMORY = 0x0004;
        const int WM_NCHITTEST = 0x0084;
        const int HTTRANSPARENT = -1;
        const int GWL_EXSTYLE = -20;
        const int WS_EX_TRANSPARENT = 0x00000020;
        const uint SWP_NOSIZE = 0x0001;
        const uint SWP_NOMOVE = 0x0002;
        const uint SWP_NOZORDER = 0x0004;
        const uint SWP_NOACTIVATE = 0x0010;
        const uint SWP_FRAMECHANGED = 0x0020;

        const int LashCount = 20;
        const float StepDt = 1f / 120f;

        readonly PointF[] pos;
        readonly PointF[] prev;
        readonly PointF[] drawPos;
        readonly byte[][] cracks;
        readonly GCHandle[] crackPins;
        readonly Random rng = new Random();

        PointF anchor;
        PointF handleTip;
        PointF grabOffset;
        float angle = -0.55f;
        float tipSpeed;
        float prevTipSpeed;
        float cooldown;
        float hintTime;
        float accum;
        float scale = 1f;
        float segLen = 14f;
        float handleLen = 92f;
        float crackThreshold = 2400f;
        int win = 860;
        bool dragging;
        bool passing;
        bool soundOn = true;
        bool armed;
        bool renderFailed;
        int sparkLife;
        PointF sparkAt;
        PointF sparkDir;

        Bitmap frame;
        ContextMenuStrip menu;
        NotifyIcon tray;
        Timer timer;
        readonly long freq = System.Diagnostics.Stopwatch.Frequency;
        long lastTick;

        public WhipForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = true;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            Text = "\u041F\u043B\u0451\u0442\u043A\u0430";
            BackColor = Color.Black;

            var screen = Screen.PrimaryScreen.WorkingArea;
            win = Math.Max(420, Math.Min(860, Math.Min(screen.Width, screen.Height) - 24));
            scale = win / 860f;
            segLen = 14.5f * scale;
            handleLen = 96f * scale;
            crackThreshold = 1550f * scale;
            Size = new Size(win, win);

            pos = new PointF[LashCount];
            prev = new PointF[LashCount];
            drawPos = new PointF[LashCount];

            anchor = new PointF(screen.Left + screen.Width / 2f, screen.Top + screen.Height / 2f);
            PlaceWindow();
            InitLash();
            for (int i = 0; i < 160; i++)
                StepPhysics();

            cracks = new byte[3][];
            crackPins = new GCHandle[3];
            for (int i = 0; i < 3; i++)
            {
                cracks[i] = WhipSound.BuildWav(WhipSound.MakeCrack(100 + i * 17));
                crackPins[i] = GCHandle.Alloc(cracks[i], GCHandleType.Pinned);
            }

            Icon = MakeIcon();
            BuildMenu();

            timer = new Timer();
            timer.Interval = 8;
            timer.Tick += delegate { OnFrame(); };
            lastTick = System.Diagnostics.Stopwatch.GetTimestamp();
        }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= WS_EX_LAYERED;
                return cp;
            }
        }

        void BuildMenu()
        {
            menu = new ContextMenuStrip();
            var top = new ToolStripMenuItem("\u041F\u043E\u0432\u0435\u0440\u0445 \u0432\u0441\u0435\u0445 \u043E\u043A\u043E\u043D");
            top.Checked = true;
            top.Click += delegate
            {
                TopMost = !TopMost;
                top.Checked = TopMost;
            };
            var snd = new ToolStripMenuItem("\u0417\u0432\u0443\u043A \u0443\u0434\u0430\u0440\u0430");
            snd.Checked = true;
            snd.Click += delegate
            {
                soundOn = !soundOn;
                snd.Checked = soundOn;
            };
            var center = new ToolStripMenuItem("\u0412\u0435\u0440\u043D\u0443\u0442\u044C \u0432 \u0446\u0435\u043D\u0442\u0440");
            center.Click += delegate { CenterOnScreen(); };
            var close = new ToolStripMenuItem("\u0417\u0430\u043A\u0440\u044B\u0442\u044C");
            close.Click += delegate { Close(); };
            menu.Items.Add(top);
            menu.Items.Add(snd);
            menu.Items.Add(center);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(close);

            tray = new NotifyIcon();
            tray.Icon = Icon;
            tray.Text = "\u041F\u043B\u0451\u0442\u043A\u0430 \u2014 \u0442\u0430\u0449\u0438 \u0438 \u0440\u0435\u0437\u043A\u043E \u0432\u0437\u043C\u0430\u0445\u043D\u0438";
            tray.Visible = true;
            tray.ContextMenuStrip = menu;
            tray.MouseDoubleClick += delegate { CenterOnScreen(); };
        }

        Icon MakeIcon()
        {
            var bmp = new Bitmap(32, 32, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                using (var pen = new Pen(Color.FromArgb(230, 120, 64, 32), 4f))
                {
                    pen.StartCap = LineCap.Round;
                    pen.EndCap = LineCap.Round;
                    g.DrawBezier(pen, 6, 24, 10, 8, 20, 6, 26, 16);
                }
                using (var br = new SolidBrush(Color.FromArgb(255, 92, 52, 28)))
                    g.FillEllipse(br, 3, 20, 8, 8);
            }
            IntPtr h = bmp.GetHicon();
            var icon = Icon.FromHandle(h);
            return icon;
        }

        void CenterOnScreen()
        {
            var screen = Screen.PrimaryScreen.WorkingArea;
            var delta = new PointF(
                screen.Left + screen.Width / 2f - anchor.X,
                screen.Top + screen.Height / 2f - anchor.Y);
            anchor = new PointF(anchor.X + delta.X, anchor.Y + delta.Y);
            for (int i = 0; i < LashCount; i++)
            {
                pos[i] = new PointF(pos[i].X + delta.X, pos[i].Y + delta.Y);
                prev[i] = new PointF(prev[i].X + delta.X, prev[i].Y + delta.Y);
            }
            UpdateHandleTip();
            PlaceWindow();
            Render();
        }

        void InitLash()
        {
            UpdateHandleTip();
            for (int i = 0; i < LashCount; i++)
            {
                float hang = i * segLen;
                pos[i] = new PointF(handleTip.X + hang * 0.15f, handleTip.Y + hang);
                prev[i] = pos[i];
            }
        }

        void UpdateHandleTip()
        {
            handleTip = new PointF(
                anchor.X + (float)Math.Cos(angle) * handleLen,
                anchor.Y + (float)Math.Sin(angle) * handleLen);
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            Render();
            SetPassThrough(true);
            timer.Start();
            armed = true;
            prevTipSpeed = 0f;
            tipSpeed = 0f;
        }

        void SetPassThrough(bool pass)
        {
            if (pass == passing || !IsHandleCreated) return;
            passing = pass;
            long style = GetWindowLongPtr(Handle, GWL_EXSTYLE).ToInt64();
            if (pass) style |= WS_EX_TRANSPARENT;
            else style &= ~WS_EX_TRANSPARENT;
            SetWindowLongPtr(Handle, GWL_EXSTYLE, new IntPtr(style));
            SetWindowPos(Handle, IntPtr.Zero, 0, 0, 0, 0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            timer.Stop();
            if (tray != null)
            {
                tray.Visible = false;
                tray.Dispose();
            }
            for (int i = 0; i < crackPins.Length; i++)
                if (crackPins[i].IsAllocated) crackPins[i].Free();
            base.OnFormClosed(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                menu.Show(Cursor.Position);
                return;
            }
            if (e.Button != MouseButtons.Left) return;
            if (!HitScreen(Cursor.Position)) return;
            dragging = true;
            Capture = true;
            Cursor = Cursors.SizeAll;
            grabOffset = new PointF(Cursor.Position.X - anchor.X, Cursor.Position.Y - anchor.Y);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            dragging = false;
            Capture = false;
            Cursor = Cursors.Hand;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (!dragging) return;
            var c = Cursor.Position;
            var target = new PointF(c.X - grabOffset.X, c.Y - grabOffset.Y);
            MoveAnchor(target);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_NCHITTEST && !dragging)
            {
                int lp = m.LParam.ToInt32();
                int x = (short)(lp & 0xFFFF);
                int y = (short)((lp >> 16) & 0xFFFF);
                if (!HitScreen(new Point(x, y)))
                {
                    m.Result = (IntPtr)HTTRANSPARENT;
                    return;
                }
            }
            base.WndProc(ref m);
        }

        void MoveAnchor(PointF target)
        {
            float dx = target.X - anchor.X;
            float dy = target.Y - anchor.Y;
            float dist = (float)Math.Sqrt(dx * dx + dy * dy);
            if (dist > 0.4f)
            {
                float targetAngle = (float)Math.Atan2(dy, dx);
                float follow = Math.Min(0.55f, dist / (180f * scale));
                angle = LerpAngle(angle, targetAngle, Math.Max(0.18f, follow));
            }
            anchor = target;
            UpdateHandleTip();
        }

        void OnFrame()
        {
            long now = System.Diagnostics.Stopwatch.GetTimestamp();
            float dt = (now - lastTick) / (float)freq;
            lastTick = now;
            if (dt > 0.05f) dt = 0.05f;
            if (dt < 0f) dt = 0f;

            if (dragging)
            {
                var c = Cursor.Position;
                MoveAnchor(new PointF(c.X - grabOffset.X, c.Y - grabOffset.Y));
            }

            accum += dt;
            int guard = 0;
            while (accum >= StepDt && guard < 8)
            {
                StepPhysics();
                accum -= StepDt;
                guard++;
            }

            cooldown -= dt;
            if (cooldown < 0f) cooldown = 0f;
            hintTime += dt;
            if (sparkLife > 0) sparkLife--;

            if (armed && soundOn && cooldown <= 0f && prevTipSpeed < crackThreshold && tipSpeed >= crackThreshold)
            {
                PlayCrack();
                cooldown = 0.20f;
                sparkLife = 10;
                sparkAt = pos[LashCount - 1];
                float vx = pos[LashCount - 1].X - prev[LashCount - 1].X;
                float vy = pos[LashCount - 1].Y - prev[LashCount - 1].Y;
                float mag = (float)Math.Sqrt(vx * vx + vy * vy);
                sparkDir = mag > 0.001f ? new PointF(vx / mag, vy / mag) : new PointF(1f, 0f);
            }
            prevTipSpeed = tipSpeed;

            if (!dragging && (menu == null || !menu.Visible))
            {
                bool over = HitScreen(Cursor.Position);
                SetPassThrough(!over);
                if (over) Cursor = Cursors.Hand;
            }

            PlaceWindow();
            Render();
        }

        void PlayCrack()
        {
            int i = rng.Next(crackPins.Length);
            PlaySound(crackPins[i].AddrOfPinnedObject(), IntPtr.Zero, SND_ASYNC | SND_MEMORY | SND_NODEFAULT);
        }

        void StepPhysics()
        {
            UpdateHandleTip();
            const float damp = 0.992f;
            float grav = 0.055f * scale;

            for (int i = 1; i < LashCount; i++)
            {
                float vx = (pos[i].X - prev[i].X) * damp;
                float vy = (pos[i].Y - prev[i].Y) * damp + grav;
                prev[i] = pos[i];
                pos[i] = new PointF(pos[i].X + vx, pos[i].Y + vy);
            }

            pos[0] = handleTip;
            prev[0] = handleTip;

            for (int iter = 0; iter < 8; iter++)
            {
                for (int i = 1; i < LashCount; i++)
                    Constrain(i, i - 1, segLen);
            }

            float tx = pos[LashCount - 1].X - prev[LashCount - 1].X;
            float ty = pos[LashCount - 1].Y - prev[LashCount - 1].Y;
            float frameSpeed = (float)Math.Sqrt(tx * tx + ty * ty) / StepDt;
            tipSpeed = tipSpeed * 0.35f + frameSpeed * 0.65f;

            for (int i = 0; i < LashCount; i++)
            {
                if (float.IsNaN(pos[i].X) || float.IsNaN(pos[i].Y))
                {
                    InitLash();
                    tipSpeed = 0f;
                    return;
                }
            }
        }

        void Constrain(int i, int j, float rest)
        {
            float dx = pos[i].X - pos[j].X;
            float dy = pos[i].Y - pos[j].Y;
            float dist = (float)Math.Sqrt(dx * dx + dy * dy);
            if (dist < 0.0001f) return;
            float diff = (dist - rest) / dist;
            float inv = i == 0 ? 0f : 0.5f;
            float jnv = j == 0 ? 0f : 0.5f;
            if (j == 0)
            {
                inv = 1f;
                jnv = 0f;
            }
            pos[i] = new PointF(pos[i].X - dx * diff * inv, pos[i].Y - dy * diff * inv);
            pos[j] = new PointF(pos[j].X + dx * diff * jnv, pos[j].Y + dy * diff * jnv);
        }

        void PlaceWindow()
        {
            int x = (int)Math.Round(anchor.X - win / 2f);
            int y = (int)Math.Round(anchor.Y - win / 2f);
            if (Location.X != x || Location.Y != y || Width != win)
                Bounds = new Rectangle(x, y, win, win);
        }

        bool HitScreen(Point screen)
        {
            var p = new PointF(screen.X, screen.Y);
            float handleHit = 20f * scale;
            if (DistToSegment(p, Pommel(), handleTip) <= handleHit) return true;
            for (int i = 1; i < LashCount; i++)
            {
                float t = i / (float)(LashCount - 1);
                float rad = Lerp(16f, 10f, t) * scale;
                if (DistToSegment(p, pos[i - 1], pos[i]) <= rad) return true;
            }
            return false;
        }

        PointF Pommel()
        {
            return new PointF(
                anchor.X - (float)Math.Cos(angle) * 18f * scale,
                anchor.Y - (float)Math.Sin(angle) * 18f * scale);
        }

        void Render()
        {
            if (!IsHandleCreated) return;
            if (frame == null || frame.Width != win || frame.Height != win)
            {
                if (frame != null) frame.Dispose();
                frame = new Bitmap(win, win, PixelFormat.Format32bppPArgb);
            }

            float ox = Left;
            float oy = Top;
            using (var g = Graphics.FromImage(frame))
            {
                g.CompositingMode = CompositingMode.SourceCopy;
                g.Clear(Color.Transparent);
                g.CompositingMode = CompositingMode.SourceOver;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

                var local = new PointF[LashCount];
                for (int i = 0; i < LashCount; i++)
                {
                    drawPos[i] = pos[i];
                    local[i] = new PointF(pos[i].X - ox, pos[i].Y - oy);
                }

                var shadow = new PointF[LashCount];
                for (int i = 0; i < LashCount; i++)
                    shadow[i] = new PointF(local[i].X + 7f * scale, local[i].Y + 12f * scale);

                var h0 = new PointF(Pommel().X - ox, Pommel().Y - oy);
                var h1 = new PointF(handleTip.X - ox, handleTip.Y - oy);
                var hs0 = new PointF(h0.X + 7f * scale, h0.Y + 12f * scale);
                var hs1 = new PointF(h1.X + 7f * scale, h1.Y + 12f * scale);

                DrawLash(g, shadow, true);
                DrawHandle(g, hs0, hs1, true);
                DrawLash(g, local, false);
                DrawHandle(g, h0, h1, false);
                DrawPopper(g, local);
                if (sparkLife > 0) DrawSpark(g, ox, oy);
                DrawHint(g, h0);
            }

            PushBitmap(frame);
        }

        void DrawLash(Graphics g, PointF[] pts, bool shadow)
        {
            int n = pts.Length;
            var left = new PointF[n];
            var right = new PointF[n];
            var braid = new PointF[n];
            for (int i = 0; i < n; i++)
            {
                float t = i / (float)(n - 1);
                float width = Lerp(11.5f * scale, 1.35f * scale, (float)Math.Pow(t, 0.85));
                PointF dir = DirAt(pts, i);
                PointF nrm = new PointF(-dir.Y, dir.X);
                left[i] = new PointF(pts[i].X + nrm.X * width, pts[i].Y + nrm.Y * width);
                right[i] = new PointF(pts[i].X - nrm.X * width, pts[i].Y - nrm.Y * width);
                float twist = (float)Math.Sin(i * 0.85) * width * 0.42f;
                braid[i] = new PointF(pts[i].X + nrm.X * twist, pts[i].Y + nrm.Y * twist);
            }

            var poly = new PointF[n * 2];
            for (int i = 0; i < n; i++) poly[i] = left[i];
            for (int i = 0; i < n; i++) poly[n + i] = right[n - 1 - i];

            if (shadow)
            {
                using (var br = new SolidBrush(Color.FromArgb(54, 0, 0, 0)))
                    g.FillPolygon(br, poly);
                return;
            }

            using (var path = new GraphicsPath())
            {
                path.AddPolygon(poly);
                using (var br = new LinearGradientBrush(
                    Bounding(poly),
                    Color.FromArgb(255, 92, 48, 24),
                    Color.FromArgb(255, 196, 122, 62),
                    LinearGradientMode.ForwardDiagonal))
                {
                    g.FillPath(br, path);
                }
                using (var pen = new Pen(Color.FromArgb(180, 48, 24, 12), Math.Max(1f, 1.4f * scale)))
                    g.DrawPath(pen, path);
            }

            using (var br = new SolidBrush(Color.FromArgb(150, 74, 36, 16)))
            {
                float r = 3.2f * scale;
                for (int i = 1; i < n - 1; i++)
                {
                    float t = i / (float)(n - 1);
                    float rad = Lerp(r, 0.8f * scale, t);
                    g.FillEllipse(br, braid[i].X - rad, braid[i].Y - rad, rad * 2f, rad * 2f);
                }
            }

            using (var pen = new Pen(Color.FromArgb(90, 255, 214, 160), Math.Max(1f, 1.1f * scale)))
            {
                pen.StartCap = LineCap.Round;
                pen.EndCap = LineCap.Round;
                var hi = new PointF[n];
                for (int i = 0; i < n; i++)
                {
                    float t = i / (float)(n - 1);
                    float width = Lerp(11.5f * scale, 1.35f * scale, (float)Math.Pow(t, 0.85));
                    PointF dir = DirAt(pts, i);
                    PointF nrm = new PointF(-dir.Y, dir.X);
                    hi[i] = new PointF(pts[i].X + nrm.X * width * 0.45f, pts[i].Y + nrm.Y * width * 0.45f);
                }
                g.DrawLines(pen, hi);
            }
        }

        void DrawHandle(Graphics g, PointF a, PointF b, bool shadow)
        {
            PointF dir = Norm(new PointF(b.X - a.X, b.Y - a.Y));
            PointF nrm = new PointF(-dir.Y, dir.X);
            float half = 9.2f * scale;
            var poly = new[]
            {
                new PointF(a.X + nrm.X * half, a.Y + nrm.Y * half),
                new PointF(b.X + nrm.X * half * 0.72f, b.Y + nrm.Y * half * 0.72f),
                new PointF(b.X - nrm.X * half * 0.72f, b.Y - nrm.Y * half * 0.72f),
                new PointF(a.X - nrm.X * half, a.Y - nrm.Y * half)
            };

            float pr = 13f * scale;
            if (shadow)
            {
                using (var br = new SolidBrush(Color.FromArgb(54, 0, 0, 0)))
                {
                    g.FillPolygon(br, poly);
                    g.FillEllipse(br, a.X - pr, a.Y - pr, pr * 2f, pr * 2f);
                }
                return;
            }

            using (var br = new LinearGradientBrush(a, b, Color.FromArgb(255, 86, 48, 28), Color.FromArgb(255, 156, 96, 58)))
                g.FillPolygon(br, poly);
            using (var pen = new Pen(Color.FromArgb(200, 40, 22, 12), Math.Max(1f, 1.3f * scale)))
                g.DrawPolygon(pen, poly);

            using (var band = new SolidBrush(Color.FromArgb(230, 58, 30, 16)))
            {
                for (int i = 1; i <= 6; i++)
                {
                    float t = i / 7.4f;
                    var c = new PointF(Lerp(a.X, b.X, t), Lerp(a.Y, b.Y, t));
                    float bw = half * 0.92f;
                    float bh = 3.1f * scale;
                    var quad = new[]
                    {
                        new PointF(c.X - dir.X * bh + nrm.X * bw, c.Y - dir.Y * bh + nrm.Y * bw),
                        new PointF(c.X + dir.X * bh + nrm.X * bw, c.Y + dir.Y * bh + nrm.Y * bw),
                        new PointF(c.X + dir.X * bh - nrm.X * bw, c.Y + dir.Y * bh - nrm.Y * bw),
                        new PointF(c.X - dir.X * bh - nrm.X * bw, c.Y - dir.Y * bh - nrm.Y * bw)
                    };
                    g.FillPolygon(band, quad);
                }
            }

            using (var br = new LinearGradientBrush(
                new RectangleF(a.X - pr, a.Y - pr, pr * 2, pr * 2),
                Color.FromArgb(255, 120, 68, 36),
                Color.FromArgb(255, 48, 26, 14),
                LinearGradientMode.ForwardDiagonal))
                g.FillEllipse(br, a.X - pr, a.Y - pr, pr * 2f, pr * 2f);

            float loopR = 8f * scale;
            var loopC = new PointF(a.X - dir.X * pr * 0.2f + nrm.X * (half + loopR * 0.15f), a.Y - dir.Y * pr * 0.2f + nrm.Y * (half + loopR * 0.15f));
            using (var pen = new Pen(Color.FromArgb(230, 92, 58, 32), 2.4f * scale))
                g.DrawEllipse(pen, loopC.X - loopR, loopC.Y - loopR, loopR * 2f, loopR * 2f);

            using (var br = new SolidBrush(Color.FromArgb(255, 214, 168, 96)))
                g.FillEllipse(br, b.X - 4f * scale, b.Y - 4f * scale, 8f * scale, 8f * scale);
        }

        void DrawPopper(Graphics g, PointF[] pts)
        {
            PointF tip = pts[pts.Length - 1];
            PointF dir = DirAt(pts, pts.Length - 2);
            using (var br = new SolidBrush(Color.FromArgb(230, 236, 214, 170)))
            {
                for (int s = -1; s <= 1; s++)
                {
                    var nrm = new PointF(-dir.Y, dir.X);
                    var end = new PointF(
                        tip.X + dir.X * 16f * scale + nrm.X * s * 4f * scale,
                        tip.Y + dir.Y * 16f * scale + nrm.Y * s * 4f * scale);
                    using (var pen = new Pen(Color.FromArgb(220, 236, 214, 170), Math.Max(1f, 1.2f * scale)))
                    {
                        pen.StartCap = LineCap.Round;
                        pen.EndCap = LineCap.Round;
                        g.DrawLine(pen, tip, end);
                    }
                }
                g.FillEllipse(br, tip.X - 2.2f * scale, tip.Y - 2.2f * scale, 4.4f * scale, 4.4f * scale);
            }
        }

        void DrawSpark(Graphics g, float ox, float oy)
        {
            float a = sparkLife / 10f;
            var origin = new PointF(sparkAt.X - ox, sparkAt.Y - oy);
            using (var pen = new Pen(Color.FromArgb((int)(220 * a), 255, 244, 210), 2f * scale))
            {
                pen.StartCap = LineCap.Round;
                pen.EndCap = LineCap.Round;
                for (int i = -2; i <= 2; i++)
                {
                    var nrm = new PointF(-sparkDir.Y, sparkDir.X);
                    var p0 = new PointF(origin.X + nrm.X * i * 3f * scale, origin.Y + nrm.Y * i * 3f * scale);
                    var p1 = new PointF(
                        p0.X - sparkDir.X * (18f + Math.Abs(i) * 6f) * scale,
                        p0.Y - sparkDir.Y * (18f + Math.Abs(i) * 6f) * scale);
                    g.DrawLine(pen, p0, p1);
                }
            }
        }

        void DrawHint(Graphics g, PointF handleLocal)
        {
            if (hintTime > 7.5f) return;
            float alpha = 1f;
            if (hintTime > 4.2f) alpha = 1f - (hintTime - 4.2f) / 3.3f;
            if (alpha <= 0f) return;
            int a = Math.Max(0, Math.Min(255, (int)(alpha * 255)));
            string line1 = "\u0422\u0430\u0449\u0438 \u0438 \u0440\u0435\u0437\u043A\u043E \u0432\u0437\u043C\u0430\u0445\u043D\u0438";
            string line2 = "\u041F\u0440\u0430\u0432\u044B\u0439 \u043A\u043B\u0438\u043A \u2014 \u043C\u0435\u043D\u044E";
            using (var font = new Font("Segoe UI", 12f * Math.Max(0.85f, scale), FontStyle.Bold, GraphicsUnit.Point))
            using (var font2 = new Font("Segoe UI", 9.5f * Math.Max(0.85f, scale), FontStyle.Regular, GraphicsUnit.Point))
            {
                var size = g.MeasureString(line1, font);
                var size2 = g.MeasureString(line2, font2);
                float w = Math.Max(size.Width, size2.Width) + 22f;
                float h = size.Height + size2.Height + 8f;
                float x = handleLocal.X - w / 2f;
                float y = handleLocal.Y - h - 18f * scale;
                using (var pill = Rounded(new RectangleF(x, y, w, h), 10f * scale))
                using (var bg = new SolidBrush(Color.FromArgb((int)(a * 0.88f), 32, 18, 10)))
                using (var edge = new Pen(Color.FromArgb((int)(a * 0.55f), 214, 168, 96), 1.4f))
                {
                    g.FillPath(bg, pill);
                    g.DrawPath(edge, pill);
                }
                FillText(g, line1, font, Color.FromArgb(a, 255, 236, 210), new PointF(x + (w - size.Width) / 2f, y + 4f));
                FillText(g, line2, font2, Color.FromArgb((int)(a * 0.85f), 232, 196, 150), new PointF(x + (w - size2.Width) / 2f, y + size.Height - 1f));
            }
        }

        static void FillText(Graphics g, string text, Font font, Color color, PointF at)
        {
            using (var path = new GraphicsPath())
            {
                float em = font.Size * g.DpiY / 72f;
                path.AddString(text, font.FontFamily, (int)font.Style, em, at, StringFormat.GenericTypographic);
                using (var br = new SolidBrush(color))
                    g.FillPath(br, path);
            }
        }

        static GraphicsPath Rounded(RectangleF r, float radius)
        {
            float d = Math.Min(radius * 2f, Math.Min(r.Width, r.Height));
            var path = new GraphicsPath();
            path.AddArc(r.X, r.Y, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        void PushBitmap(Bitmap bmp)
        {
            int w = bmp.Width;
            int h = bmp.Height;
            var bits = bmp.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format32bppPArgb);
            IntPtr screenDc = IntPtr.Zero;
            IntPtr memDc = IntPtr.Zero;
            IntPtr dib = IntPtr.Zero;
            IntPtr old = IntPtr.Zero;
            try
            {
                screenDc = GetDC(IntPtr.Zero);
                memDc = CreateCompatibleDC(screenDc);

                var bmi = new BITMAPINFO();
                bmi.bmiHeader.biSize = 40;
                bmi.bmiHeader.biWidth = w;
                bmi.bmiHeader.biHeight = -h;
                bmi.bmiHeader.biPlanes = 1;
                bmi.bmiHeader.biBitCount = 32;
                bmi.bmiHeader.biCompression = 0;
                bmi.bmiHeader.biSizeImage = (uint)(w * h * 4);

                IntPtr dstBits;
                dib = CreateDIBSection(screenDc, ref bmi, 0, out dstBits, IntPtr.Zero, 0);
                if (dib == IntPtr.Zero || dstBits == IntPtr.Zero)
                    throw new InvalidOperationException("CreateDIBSection failed: " + Marshal.GetLastWin32Error());

                int rowBytes = w * 4;
                var row = new byte[rowBytes];
                for (int y = 0; y < h; y++)
                {
                    IntPtr src = IntPtr.Add(bits.Scan0, y * bits.Stride);
                    Marshal.Copy(src, row, 0, rowBytes);
                    Marshal.Copy(row, 0, IntPtr.Add(dstBits, y * rowBytes), rowBytes);
                }

                old = SelectObject(memDc, dib);
                var dst = new Point(Left, Top);
                var size = new Size(w, h);
                var srcPt = new Point(0, 0);
                var blend = new BLENDFUNCTION
                {
                    BlendOp = AC_SRC_OVER,
                    BlendFlags = 0,
                    SourceConstantAlpha = 255,
                    AlphaFormat = AC_SRC_ALPHA
                };
                if (!UpdateLayeredWindow(Handle, screenDc, ref dst, ref size, memDc, ref srcPt, 0, ref blend, ULW_ALPHA))
                {
                    if (!renderFailed)
                    {
                        renderFailed = true;
                        throw new InvalidOperationException("UpdateLayeredWindow failed: " + Marshal.GetLastWin32Error());
                    }
                }
            }
            finally
            {
                bmp.UnlockBits(bits);
                if (old != IntPtr.Zero && memDc != IntPtr.Zero) SelectObject(memDc, old);
                if (dib != IntPtr.Zero) DeleteObject(dib);
                if (memDc != IntPtr.Zero) DeleteDC(memDc);
                if (screenDc != IntPtr.Zero) ReleaseDC(IntPtr.Zero, screenDc);
            }
        }

        static RectangleF Bounding(PointF[] pts)
        {
            float minX = pts[0].X, minY = pts[0].Y, maxX = pts[0].X, maxY = pts[0].Y;
            for (int i = 1; i < pts.Length; i++)
            {
                if (pts[i].X < minX) minX = pts[i].X;
                if (pts[i].Y < minY) minY = pts[i].Y;
                if (pts[i].X > maxX) maxX = pts[i].X;
                if (pts[i].Y > maxY) maxY = pts[i].Y;
            }
            if (maxX - minX < 1f) maxX = minX + 1f;
            if (maxY - minY < 1f) maxY = minY + 1f;
            return new RectangleF(minX, minY, maxX - minX, maxY - minY);
        }

        static PointF DirAt(PointF[] pts, int i)
        {
            int a = Math.Max(0, i - 1);
            int b = Math.Min(pts.Length - 1, i + 1);
            return Norm(new PointF(pts[b].X - pts[a].X, pts[b].Y - pts[a].Y));
        }

        static PointF Norm(PointF v)
        {
            float m = (float)Math.Sqrt(v.X * v.X + v.Y * v.Y);
            if (m < 0.0001f) return new PointF(1f, 0f);
            return new PointF(v.X / m, v.Y / m);
        }

        static float DistToSegment(PointF p, PointF a, PointF b)
        {
            float dx = b.X - a.X;
            float dy = b.Y - a.Y;
            float len2 = dx * dx + dy * dy;
            if (len2 < 0.0001f) return Dist(p, a);
            float t = ((p.X - a.X) * dx + (p.Y - a.Y) * dy) / len2;
            if (t < 0f) t = 0f;
            else if (t > 1f) t = 1f;
            return Dist(p, new PointF(a.X + dx * t, a.Y + dy * t));
        }

        static float Dist(PointF a, PointF b)
        {
            float dx = a.X - b.X;
            float dy = a.Y - b.Y;
            return (float)Math.Sqrt(dx * dx + dy * dy);
        }

        static float Lerp(float a, float b, float t)
        {
            return a + (b - a) * t;
        }

        static float LerpAngle(float a, float b, float t)
        {
            float d = b - a;
            while (d > Math.PI) d -= (float)(Math.PI * 2);
            while (d < -Math.PI) d += (float)(Math.PI * 2);
            return a + d * t;
        }

        [DllImport("user32.dll", ExactSpelling = true, SetLastError = true)]
        static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref Point pptDst, ref Size psize, IntPtr hdcSrc, ref Point pptSrc, int crKey, ref BLENDFUNCTION pblend, int dwFlags);

        [DllImport("user32.dll")]
        static extern IntPtr GetDC(IntPtr hWnd);

        [DllImport("user32.dll")]
        static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

        [DllImport("gdi32.dll")]
        static extern IntPtr CreateCompatibleDC(IntPtr hdc);

        [DllImport("gdi32.dll")]
        static extern bool DeleteDC(IntPtr hdc);

        [DllImport("gdi32.dll")]
        static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);

        [DllImport("gdi32.dll")]
        static extern bool DeleteObject(IntPtr hObject);

        [DllImport("gdi32.dll", SetLastError = true)]
        static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFO pbmi, uint usage, out IntPtr bits, IntPtr section, uint offset);

        [DllImport("winmm.dll", EntryPoint = "PlaySoundW", SetLastError = true)]
        static extern bool PlaySound(IntPtr pszSound, IntPtr hmod, uint fdwSound);

        [DllImport("user32.dll", EntryPoint = "GetWindowLongPtrW")]
        static extern IntPtr GetWindowLongPtr(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW")]
        static extern IntPtr SetWindowLongPtr(IntPtr hWnd, int nIndex, IntPtr dwNewLong);

        [DllImport("user32.dll", SetLastError = true)]
        static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int x, int y, int cx, int cy, uint flags);
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    struct BLENDFUNCTION
    {
        public byte BlendOp;
        public byte BlendFlags;
        public byte SourceConstantAlpha;
        public byte AlphaFormat;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct BITMAPINFOHEADER
    {
        public uint biSize;
        public int biWidth;
        public int biHeight;
        public ushort biPlanes;
        public ushort biBitCount;
        public uint biCompression;
        public uint biSizeImage;
        public int biXPelsPerMeter;
        public int biYPelsPerMeter;
        public uint biClrUsed;
        public uint biClrImportant;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct BITMAPINFO
    {
        public BITMAPINFOHEADER bmiHeader;
        public uint bmiColors;
    }

    static class WhipSound
    {
        public static short[] MakeCrack(int seed)
        {
            const int rate = 44100;
            const double dur = 0.26;
            int n = (int)(rate * dur);
            var samples = new short[n];
            var rng = new Random(seed);
            double lp = 0;
            double hp = 0;
            double prev = 0;
            double phase = 0;
            for (int i = 0; i < n; i++)
            {
                double t = i / (double)rate;
                double white = rng.NextDouble() * 2 - 1;
                hp = white - prev + 0.965 * hp;
                prev = white;
                double cutoff = 0.12 + 0.82 * Math.Exp(-t * 28.0);
                lp += cutoff * (white - lp);

                double snap = Math.Exp(-t * 48.0);
                double body = Math.Exp(-t * 11.0);
                double click = Math.Exp(-t * 380.0);
                phase += 2.0 * Math.PI * (2600.0 * Math.Exp(-t * 36.0) + 160.0) / rate;
                double tone = Math.Sin(phase) * Math.Exp(-t * 42.0);

                double sample = hp * snap * 0.9 + lp * body * 0.28 + white * click * 1.05 + tone * 0.62;
                sample = Math.Tanh(sample * 2.15);
                samples[i] = (short)(sample * 31000.0);
            }
            return samples;
        }

        public static byte[] BuildWav(short[] samples)
        {
            const int rate = 44100;
            int dataSize = samples.Length * 2;
            var wav = new byte[44 + dataSize];
            WriteAscii(wav, 0, "RIFF");
            Write32(wav, 4, 36 + dataSize);
            WriteAscii(wav, 8, "WAVE");
            WriteAscii(wav, 12, "fmt ");
            Write32(wav, 16, 16);
            Write16(wav, 20, 1);
            Write16(wav, 22, 1);
            Write32(wav, 24, rate);
            Write32(wav, 28, rate * 2);
            Write16(wav, 32, 2);
            Write16(wav, 34, 16);
            WriteAscii(wav, 36, "data");
            Write32(wav, 40, dataSize);
            Buffer.BlockCopy(samples, 0, wav, 44, dataSize);
            return wav;
        }

        static void WriteAscii(byte[] b, int o, string s)
        {
            for (int i = 0; i < s.Length; i++) b[o + i] = (byte)s[i];
        }

        static void Write16(byte[] b, int o, int v)
        {
            b[o] = (byte)v;
            b[o + 1] = (byte)(v >> 8);
        }

        static void Write32(byte[] b, int o, int v)
        {
            b[o] = (byte)v;
            b[o + 1] = (byte)(v >> 8);
            b[o + 2] = (byte)(v >> 16);
            b[o + 3] = (byte)(v >> 24);
        }
    }
}
